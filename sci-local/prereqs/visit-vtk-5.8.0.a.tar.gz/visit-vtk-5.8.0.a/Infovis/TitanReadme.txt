The Infovis classes in VTK are brought to you by the Titan Informatics
Toolkit Project. The Titan project is an collaborative effort between
Sandia National Laboratories and Kitware Inc. to combine SciVis and 
InfoVis capabilities into one scalable infrastructure.

Sandia is a multi-program laboratory operated by Sandia Corporation, a
Lockheed Martin Company, for the United States Department of Energy under
Contract DE-AC04-94AL85000.

Go Titan!!!!

       _______ __
      /_  __(_) /_____ _____
       / / / / __/ __ `/ __ \
      / / / / /_/ /_/ / / / /
     /_/ /_/\__/\__,_/_/ /_/
            VTK Informatics Toolkit

