Table of contents
*****************
.. toctree::
    :numbered:
    :maxdepth: 3

    faq.rst
    overview.rst
    commandlineoptions.rst
    projectfile.rst
    typesystemvariables.rst
    typeconverters.rst
    codeinjectionsemantics.rst
    sequenceprotocol.rst
    ownership.rst
    wordsofadvice.rst
    shibokenmodule.rst
