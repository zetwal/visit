struct Dummy {};
