#include "../samplebinding/global.h"
#include "extendsnoimplicitconversion.h"
#include "number.h"
#include "otherderived.h"
#include "otherobjecttype.h"
#include "othermultiplederived.h"

